# Tésis de Licenciatura en Ciencia de Datos

<img src="imgs/itam.png" width="500" height="200">


**Tema:** Modelos Extensos de Lenguaje como alternativa a la función de recompensas en Q-Learning aplicado a juegos.

## Tabla de contenidos

- [Introducción](#Introducción)


## Introducción

Aquí va la introducción a la página de GitHub.

